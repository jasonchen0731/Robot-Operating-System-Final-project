#!/usr/bin/env python3

import rospy
from std_msgs.msg import String


def state_manager():
    rospy.init_node('state_manager')
    pub = rospy.Publisher('/robot_state', String, queue_size=10)
    rate = rospy.Rate(0.2)  # 每5秒發送一次

    states = ['IDLE', 'MOVING', 'STOPPED']
    index = 0

    while not rospy.is_shutdown():
        state_msg = String()
        state_msg.data = states[index]
        rospy.loginfo(f"Current state：{state_msg.data}")
        pub.publish(state_msg)
        index = (index + 1) % len(states)
        rate.sleep()


if __name__ == '__main__':
    try:
        state_manager()
    except rospy.ROSInterruptException:
        pass
