#!/usr/bin/env python3

import rospy
from std_msgs.msg import String


def callback(msg):
    if msg.data == 'IDLE':
        state = "Linear velocity = 0.0"
        state1 = "Angular velocity = 0.0"
    elif msg.data == 'STOPPED':
        state = "Linear velocity = 0.0"
        state1 = "Angular velocity = 0.0"
    elif msg.data == 'MOVING':
        state = "Linear velocity = 1.0"
        state1 = "Angular velocity = 0.5"

    rospy.loginfo("===System Status===")
    rospy.loginfo(f"Robot State：{msg.data}")
    rospy.loginfo(f"{state}")
    rospy.loginfo(f"{state1}")
    rospy.loginfo("===================")


def monitor():
    rospy.init_node('monitor')
    rospy.Subscriber('/robot_state', String, callback)
    rospy.spin()


if __name__ == '__main__':
    try:
        monitor()
    except rospy.ROSInterruptException:
        pass
