#!/usr/bin/env python3

import rospy
from std_msgs.msg import String
from geometry_msgs.msg import Twist


def callback(msg):
    vel_pub = rospy.Publisher('/cmd_vel', Twist, queue_size=10)
    twist = Twist()

    if msg.data == 'IDLE':
        twist.linear.x = 0.0
        twist.angular.z = 0.0
    elif msg.data == 'STOPPED':
        twist.linear.x = 0.0
        twist.angular.z = 0.0
    elif msg.data == 'MOVING':
        twist.linear.x = 1.0
        twist.angular.z = 0.5

    rospy.loginfo(
        f"State：{msg.data}，Sending：linear={twist.linear.x}, angular={twist.angular.z}")
    vel_pub.publish(twist)


def velocity_controller():
    rospy.init_node('velocity_controller')
    rospy.Subscriber('/robot_state', String, callback)
    rospy.spin()


if __name__ == '__main__':
    try:
        velocity_controller()
    except rospy.ROSInterruptException:
        pass
