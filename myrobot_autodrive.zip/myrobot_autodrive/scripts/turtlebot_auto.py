#!/usr/bin/env python3
import rospy
from sensor_msgs.msg import LaserScan
from nav_msgs.msg import Odometry
from geometry_msgs.msg import Twist
import math

DEG2RAD = math.pi / 180.0
LINEAR_VELOCITY = 0.2
ANGULAR_VELOCITY = 1.5

# 狀態定義
GET_DIRECTION = 0
DRIVE_FORWARD = 1
TURN_LEFT = 2
TURN_RIGHT = 3

CENTER = 0
LEFT = 1
RIGHT = 2


class Turtlebot3Drive:
    def __init__(self):
        rospy.init_node('turtlebot3_drive_python')
        rospy.loginfo("TurtleBot3 Python 模擬節點初始化")

        self.cmd_pub = rospy.Publisher('/tb3/cmd_vel', Twist, queue_size=10)
        rospy.Subscriber('/tb3/scan', LaserScan, self.laser_callback)
        rospy.Subscriber('/tb3/odom', Odometry, self.odom_callback)

        self.tb3_pose = 0.0
        self.prev_tb3_pose = 0.0

        self.scan_data = [0.0, 0.0, 0.0]  # [center, left, right]
        self.escape_range = 30.0 * DEG2RAD
        self.check_forward_dist = 0.7
        self.check_side_dist = 0.6

        self.state = GET_DIRECTION

    def odom_callback(self, msg):
        # 取出yaw角（機器人面向的角度）
        orientation = msg.pose.pose.orientation
        siny = 2.0 * (orientation.w * orientation.z +
                      orientation.x * orientation.y)
        cosy = 1.0 - 2.0 * (orientation.y**2 + orientation.z**2)
        self.tb3_pose = math.atan2(siny, cosy)

    def laser_callback(self, msg):
        # 讀取正前方、左邊、右邊距離資料（角度：0, 30, 330）
        angles = [0, 30, 330]
        for i, angle in enumerate(angles):
            dist = msg.ranges[angle]
            self.scan_data[i] = dist if not math.isinf(dist) else msg.range_max

    def update_velocity(self, linear, angular):
        cmd = Twist()
        cmd.linear.x = linear
        cmd.angular.z = angular
        self.cmd_pub.publish(cmd)

    def control_loop(self):
        # 狀態機控制邏輯
        if self.state == GET_DIRECTION:
            if self.scan_data[CENTER] > self.check_forward_dist:
                if self.scan_data[LEFT] < self.check_side_dist:
                    self.prev_tb3_pose = self.tb3_pose
                    self.state = TURN_RIGHT
                elif self.scan_data[RIGHT] < self.check_side_dist:
                    self.prev_tb3_pose = self.tb3_pose
                    self.state = TURN_LEFT
                else:
                    self.state = DRIVE_FORWARD
            else:
                self.prev_tb3_pose = self.tb3_pose
                self.state = TURN_RIGHT

        elif self.state == DRIVE_FORWARD:
            self.update_velocity(LINEAR_VELOCITY, 0.0)
            self.state = GET_DIRECTION

        elif self.state == TURN_RIGHT:
            if abs(self.tb3_pose - self.prev_tb3_pose) >= self.escape_range:
                self.state = GET_DIRECTION
            else:
                self.update_velocity(0.0, -ANGULAR_VELOCITY)

        elif self.state == TURN_LEFT:
            if abs(self.tb3_pose - self.prev_tb3_pose) >= self.escape_range:
                self.state = GET_DIRECTION
            else:
                self.update_velocity(0.0, ANGULAR_VELOCITY)

    def run(self):
        rate = rospy.Rate(10)
        while not rospy.is_shutdown():
            self.control_loop()
            rate.sleep()


if __name__ == '__main__':
    node = Turtlebot3Drive()
    node.run()
