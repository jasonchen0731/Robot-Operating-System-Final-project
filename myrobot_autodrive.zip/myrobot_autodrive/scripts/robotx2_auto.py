#!/usr/bin/env python3
import rospy
from sensor_msgs.msg import LaserScan
from geometry_msgs.msg import Twist
import math

# 常數設定
LINEAR_VELOCITY = 0.2
ANGULAR_VELOCITY = 1.5

# 狀態定義
GET_DIRECTION = 0
DRIVE_FORWARD = 1
TURN_LEFT = 2
TURN_RIGHT = 3

CENTER = 0
LEFT = 1
RIGHT = 2


class MyrobotDriveWideScan:
    def __init__(self):
        rospy.init_node('myrobot_drive')
        rospy.loginfo("Node starts ...")

        self.cmd_pub = rospy.Publisher('/mybot/cmd_vel', Twist, queue_size=10)
        rospy.Subscriber('/scan', LaserScan, self.laser_callback)

        self.scan_data = [0.0, 0.0, 0.0]  # [center, left, right]
        self.check_forward_dist = 0.8
        self.check_side_dist = 0.6

        self.state = GET_DIRECTION

    def laser_callback(self, msg: LaserScan):
        ranges = msg.ranges

        # helper 函數：取得某個角度範圍內的最小距離

        def get_region_min(start_deg, end_deg):
            start_idx = int((start_deg * math.pi / 180 -
                            msg.angle_min) / msg.angle_increment)
            end_idx = int((end_deg * math.pi / 180 -
                          msg.angle_min) / msg.angle_increment)
            index_range = ranges[start_idx:end_idx]
            filtered = [r if not math.isinf(
                r) else msg.range_max for r in index_range]
            return min(filtered) if filtered else msg.range_max

        # 偵測三個方向的距離（取最小值）
        self.scan_data[CENTER] = get_region_min(-10, 10)
        self.scan_data[LEFT] = get_region_min(30, 60)
        self.scan_data[RIGHT] = get_region_min(300, 330)

    def update_velocity(self, linear, angular):
        cmd = Twist()
        cmd.linear.x = linear
        cmd.angular.z = angular
        self.cmd_pub.publish(cmd)

    def control_loop(self):
        if self.state == GET_DIRECTION:
            if self.scan_data[CENTER] > self.check_forward_dist:
                if self.scan_data[LEFT] < self.check_side_dist:
                    self.state = TURN_RIGHT
                elif self.scan_data[RIGHT] < self.check_side_dist:
                    self.state = TURN_LEFT
                else:
                    self.state = DRIVE_FORWARD
            else:
                self.state = TURN_RIGHT

        elif self.state == DRIVE_FORWARD:
            self.update_velocity(LINEAR_VELOCITY, 0.0)
            self.state = GET_DIRECTION

        elif self.state == TURN_RIGHT:
            self.update_velocity(0.0, -ANGULAR_VELOCITY)
            rospy.sleep(2.0)
            self.state = GET_DIRECTION

        elif self.state == TURN_LEFT:
            self.update_velocity(0.0, ANGULAR_VELOCITY)
            rospy.sleep(2.0)
            self.state = GET_DIRECTION

    def run(self):
        rate = rospy.Rate(10)
        while not rospy.is_shutdown():
            self.control_loop()
            rate.sleep()


if __name__ == '__main__':
    node = MyrobotDriveWideScan()
    node.run()
