#!/usr/bin/env python3
import rospy
from sensor_msgs.msg import LaserScan
from geometry_msgs.msg import Twist
import math

# 常數設定
DEG2RAD = math.pi / 180.0
LINEAR_VELOCITY = 0.2
ANGULAR_VELOCITY = 1.5

# 狀態定義
GET_DIRECTION = 0
DRIVE_FORWARD = 1
TURN_LEFT = 2
TURN_RIGHT = 3

CENTER = 0
LEFT = 1
RIGHT = 2


class MyrobotDriveSimple:
    def __init__(self):
        rospy.init_node('Myrobot_drive_simple')
        rospy.loginfo("Node starts ...")

        # 發布速度命令
        self.cmd_pub = rospy.Publisher('/cmd_vel', Twist, queue_size=10)
        # 訂閱雷達資料
        rospy.Subscriber('/scan', LaserScan, self.laser_callback)

        self.scan_data = [0.0, 0.0, 0.0]  # [center, left, right]
        self.check_forward_dist = 0.7
        self.check_side_dist = 0.6

        self.state = GET_DIRECTION

    def laser_callback(self, msg):
        # 取得三個方向（前、左、右）的距離
        angles = [0, 30, 330]
        for i, angle in enumerate(angles):
            dist = msg.ranges[angle]
            self.scan_data[i] = dist if not math.isinf(dist) else msg.range_max

    def update_velocity(self, linear, angular):
        cmd = Twist()
        cmd.linear.x = linear
        cmd.angular.z = angular
        self.cmd_pub.publish(cmd)

    def control_loop(self):
        # 基於雷達資料的簡單避障邏輯
        if self.state == GET_DIRECTION:
            if self.scan_data[CENTER] > self.check_forward_dist:
                if self.scan_data[LEFT] < self.check_side_dist:
                    self.state = TURN_RIGHT
                elif self.scan_data[RIGHT] < self.check_side_dist:
                    self.state = TURN_LEFT
                else:
                    self.state = DRIVE_FORWARD
            else:
                self.state = TURN_RIGHT

        elif self.state == DRIVE_FORWARD:
            self.update_velocity(LINEAR_VELOCITY, 0.0)
            self.state = GET_DIRECTION

        elif self.state == TURN_RIGHT:
            self.update_velocity(0.0, -ANGULAR_VELOCITY)
            rospy.sleep(2.0)
            self.state = GET_DIRECTION

        elif self.state == TURN_LEFT:
            self.update_velocity(0.0, ANGULAR_VELOCITY)
            rospy.sleep(2.0)
            self.state = GET_DIRECTION

    def run(self):
        rate = rospy.Rate(10)
        while not rospy.is_shutdown():
            self.control_loop()
            rate.sleep()


if __name__ == '__main__':
    node = MyrobotDriveSimple()
    node.run()
